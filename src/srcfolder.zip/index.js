import { render } from "@testing-library/react";
import React, { Component } from "react";
import ReactDOM from "react-dom/client";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import "./styles/index.css";
import homeImage from "./images/home.jpg";
import sonicImage from "./images/sonic.jpg";
import paragraphs1fromfile from "./paragraphs1.js";
import paragraphs2fromfile from "./paragraphs2.js";
import paragraphs3fromfile from "./paragraphs3.js";
import paragraphs4fromfile from "./paragraphs4.js";

const titlesGlobal = ["Unshackle", "Unshackle", "Unshackle", "Unshackle"];
const navButtonsGlobal = [
  "Home Page",
  "Information Page",
  "Compilation Page",
  "About Us",
];
const headersGlobal = [
  "Welcome to the homepage",
  "Information Page",
  "Compilation Page",
  "About Us",
];

const imageGlobal = [homeImage, sonicImage, homeImage, homeImage];
const imageCarousel = [
  homeImage,
  sonicImage,
  homeImage,
  sonicImage,
  homeImage,
  sonicImage,
];
const textCarousel = [
  "image1",
  "image2",
  "image3",
  "image4",
  "image5",
  "image6",
];
const imageWidth = [300, 300, 300, 300];
const imageHeight = [200, 200, 200, 200];
const paragraphs1 = paragraphs1fromfile;
const paragraphs2 = paragraphs2fromfile;
const paragraphs3 = paragraphs3fromfile;
const paragraphs4 = paragraphs4fromfile;

class Page extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      whichPage: 0,
      navbarButtons: navButtonsGlobal,
    };
  }

  render() {
    return (
      <div>
        <div className="title">
          <Title index={this.state.whichPage} />
        </div>

        <div className="nav-bar-background">
          <div className="nav-bar-buttons">
            <NavigationButtons
              navbarButtons={this.state.navbarButtons}
              whichPage={this.state.whichPage}
              onChange={(value) => this.setState({ whichPage: value })}
            />
          </div>
        </div>
        <div className="contents">
          <Image whichPage={this.state.whichPage} />
          <Contents
            whichPage={this.state.whichPage}
            onChange={(value) => this.setState({ whichPage: value })}
          />
        </div>
        <div className="footer-background">
          <Footer />
        </div>
      </div>
    );
  }
}

class Footer extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return (
      <div className="footer">
        <p> </p>
      </div>
    );
  }
}

class Contents extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      paragraphs: "0",
    };
  }

  headersToShow = (i) => {
    const headers = headersGlobal;
    return headers[i];
  };

  buildParagraphs = (paragraphs) => {
    this.state.paragraphs = paragraphs;
    var builtParagraphs = this.state.paragraphs.map((paragraphs, i) => {
      return <p>{paragraphs}</p>;
    });
    return <div>{builtParagraphs}</div>;
  };

  paragraphToShow = (i) => {
    var paragraphs;
    switch (i + 1) {
      case 1:
        return this.buildParagraphs(paragraphs1);
      case 2:
        return this.buildParagraphs(paragraphs2);
      case 3:
        return this.buildParagraphs(paragraphs3);
      case 4:
        return this.buildParagraphs(paragraphs4);
    }
    return "this page doesnt have any paragraphs";
  };

  render() {
    return (
      <div>
        <div className="headers">
          <h1>{this.headersToShow(this.props.whichPage)}</h1>
        </div>
        <div className="paragraphs">
          {this.paragraphToShow(this.props.whichPage)}
        </div>
      </div>
    );
  }
}

class ImageCarousel extends Component {
  render() {
    var carousel = imageCarousel.map((imagesource, i) => {
      return (
        <div>
          <img src={imagesource} />
          <p className="legend">{textCarousel[i]}</p>
        </div>
      );
    });
    return (
      <div className="c1">
        <Carousel>{carousel}</Carousel>
      </div>
    );
  }
}

class Image extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      whichPage: props.whichPage,
    };
  }

  imageToRender = (i) => {
    const imageToRender = imageGlobal[i];
    return imageToRender;
  };

  imageOrCarousel = (i) => {
    if (i == 0) {
      return <ImageCarousel />;
    } else
      return (
        <div className="image">
          <img
            src={this.imageToRender(this.props.whichPage)}
            alt={this.imageToRender(this.props.whichPage)}
            width={imageWidth[this.props.whichPage]}
            height={imageHeight[this.props.whichPage]}
          ></img>
        </div>
      );
  };

  render() {
    return <div>{this.imageOrCarousel(this.props.whichPage)}</div>;
  }
}

class NavigationButtons extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      navbarButtons: props.navbarButtons,
      whichPage: props.whichPage,
    };
  }

  render() {
    var allButtons = this.props.navbarButtons.map((button, i) => {
      return (
        <button
          className="navbarButton"
          key={i}
          onClick={(event) => this.props.onChange(i)}
        >
          {button}
        </button>
      );
    });
    return <div>{allButtons}</div>;
  }
}

function Title(props) {
  let titles = titlesGlobal;
  return titles[props.index];
}

class Website extends React.Component {
  render() {
    return (
      <div className="website">
        <Page />
      </div>
    );
  }
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<Website />);
