const paragraphs = [<p>p4-1</p>, <p>p4-2</p>, <p>p4-3</p>, <p>p4-4</p>];
export default paragraphs;
