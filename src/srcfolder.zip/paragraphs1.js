const paragraphs = [
  //each paragraph must have <p> tags around, seperated by a comma as below, and then you can add whatever tags inside,
  //for example <strong></strong> around something you want to make bold
  <p>
    <strong>This</strong> is example text of what the paragraphs would look like
  </p>,
  <p>heres another one</p>,
  <p>oh look, another paragraph</p>,
  <p>thats crazy</p>,
];
export default paragraphs;
