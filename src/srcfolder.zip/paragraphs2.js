const paragraphs = [<p>p2-1</p>, <p>p2-2</p>, <p>p2-3</p>, <p>p2-4</p>];
export default paragraphs;
